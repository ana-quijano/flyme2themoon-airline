﻿Module modFlyMe2theMoon

    Public intCustomerID As Integer
    Public intPilotID As Integer
    Public intAttendantID As Integer
    Public intAddColumn As Integer

End Module
